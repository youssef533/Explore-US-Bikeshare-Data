import pandas as pd
import numpy as np
import time

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }

def get_input_user():
    print('-'*40)
    print('Lets Ask some Question to Know What data do you want to represent?')
    while True:
        print('please enter the city number you would like to check in (Chicago, New York City and Washington')
        city_input=input()
        if city_input not in ('chicago' , 'new york city','washington'):
           print('sorry this city in not available now')
           continue
        else: 
           break
    while True:
       print('Would you like to filter the data by month, day, both, or not at all? \n if you want to choose bot please write none')
       filter_input=input()
       if filter_input not in ('month','day','both','none'):
          print('please check for spilling or availabe option. ') 
          continue
       else: break
    
    while True:
      print('please choose a availbe month. as number ')
      print(' january = 1\n februray = 2\n march = 3\n april = 4 \n may = 5 \n june = 6  ')
      month_input=int(input())
      if month_input not in (1,2,3,4,5,6):
          print('please enter the available month')
          continue
      else: break
    while True:
       print('what day do you prefer?')
       print('Which day - Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, or Sunday? please type your reponse an intger \n as saturday =1')
       print('if you want to choose all day write 7')
       day_input=int(input())
       if day_input not in (1,2,3,4,5,6,7,8):
           continue
       else: break
      
    return city_input,month_input,day_input
  
    
def load_data(city,month,day):
    df=pd.read_csv(CITY_DATA.get(city))
    df['Start Time']=pd.to_datetime(df['Start Time'])

    df['Month']=df['Start Time'].dt.month
    df['Day']=df['Start Time'].dt.day
    df['hour']=df['Start Time'].dt.hour
    if month != 'all':
        # use the index of the months list to get the corresponding int
        months = [1, 2, 3, 4, 5, 6]
        month = months.index(month) +1

        # filter by month to create the new dataframe
        df = df[df['Month'] == month]

    # filter by day of week if applicable
    if day != 'all':
        # filter by day of week to create the new dataframe
        df = df[df['Day'] == day]
          
        

    return df


def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # TO DO: display the most common month
    popular_month = df['Month'].mode()[0]
    print("Most popular Month is {}".format(popular_month))



    # TO DO: display the most common day of week
    popular_day = df['Day'].mode()[0]
    print("Most popular Day is {}".format(popular_day))

    # TO DO: display the most common start hour
    popular_hour= df['hour'].mode()[0]
    print("Most popular hour is {}".format(popular_hour))


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
 

def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # TO DO: display most commonly used start station
    popular_start_station = df['Start Station'].mode()[0]
    print("Most popular Start Station is {}".format(popular_start_station))
    


    # TO DO: display most commonly used end station
    popular_end_station = df['End Station'].mode()[0]
    print("Most popular Start Station is {}".format(popular_end_station))
    

    


    # TO DO: display most frequent combination of start station and end station trip
    popular_combination_station=df.groupby(['Start Station','End Station']).size().nlargest(1)
    print("Most Frequent Combination of Start and End Station is\n {}".format(popular_combination_station))
  
    


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
    



def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # TO DO: display total travel time
    total_travel_time=df['Trip Duration'].sum()
    print("Total travel time is {}".format(total_travel_time))

    
    print("Count is {}".format(df['Trip Duration'].count()))
    # TO DO: display mean travel time
    mean_total_travel_time=df['Trip Duration'].mean()
    print("Average of total travel time is {}".format(mean_total_travel_time))
    
    
  


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()
    
    # TO DO: Display counts of user types
    counts_user_types = df['User Type'].value_counts()

    print(counts_user_types)
    
    
    # TO DO: Display counts of gender
    try:
     counts_of_gender=df['Gender'].value_counts()
     print(counts_of_gender)
    except:
     print("this data for gender ,not available for this city")


    # TO DO: Display earliest, most recent, and most common year of birth
    try:
     most_common_of_birth=df['Birth Year'].mode()[0]
     print("Most common year of birth is {}".format(most_common_of_birth))
    except:
     print("this data for most common year ,not available for this city")
    try: 
     most_recent_of_birth=df['Birth Year'].min()
     print("Most recent year of birth is {}".format(most_recent_of_birth))
    except:
     print("this data for recent birth, not available for this city")
     
    try:
    
     most_earliest_of_birth=df['Birth Year'].max()
     print("Most earliedt year of birth is {}".format(most_earliest_of_birth))
    except:
     print("this data for earliest birth, not available for this city")
   
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def dispaly_row_Data(city):
    
    while True:
     print('would you like to see 5 rows of data ?  write yes or no \n')
     answer_of_display=input()
     if answer_of_display != "yes":
        break
     else:
        city_dispaly_data=pd.read_csv("{}.csv".format(city)) 
        print(city_dispaly_data.sample(n=5))
        continue    



def main():
    while True:
        city, month, day = get_input_user()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)
        dispaly_row_Data(city)
    

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            print("thank you for visiting my Project")
            break


if __name__ == "__main__":
	main()



